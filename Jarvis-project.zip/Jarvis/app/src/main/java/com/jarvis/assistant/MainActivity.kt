package com.jarvis.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private lateinit var keyInput: EditText
    private lateinit var micStatus: TextView
    private lateinit var overlayStatus: TextView
    private lateinit var serviceStatus: TextView
    private lateinit var toggleBtn: Button

    private val colorBg = Color.parseColor("#0B1020")
    private val colorCard = Color.parseColor("#151C33")
    private val colorAccent = Color.parseColor("#2979FF")
    private val colorDanger = Color.parseColor("#E53935")
    private val colorOk = Color.parseColor("#43A047")
    private val colorMuted = Color.parseColor("#9AA4C0")

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            refreshStatus()
            if (!canDrawOverlay()) requestOverlayPermission()
        }

    private val overlayLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            refreshStatus()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = colorBg
        window.navigationBarColor = colorBg
        buildUi()
        keyInput.setText(prefs().getString(FloatingJarvisService.KEY_API, "") ?: "")
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    // ---------------------------------------------------------------- UI

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(36), dp(20), dp(24))
        }

        root.addView(text("JARVIS", 34f, Color.WHITE, true))
        root.addView(text("Voice AI agent powered by Gemini", 14f, colorMuted, false).apply {
            setPadding(0, 0, 0, dp(20))
        })

        // API key card
        val keyCard = card()
        keyCard.addView(text("Gemini API Key", 16f, Color.WHITE, true))
        keyCard.addView(text("Get a free key at aistudio.google.com/apikey", 12f, colorMuted, false))
        keyInput = EditText(this).apply {
            hint = "Paste API key here"
            setHintTextColor(colorMuted)
            setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            isSingleLine = true
            textSize = 15f
            background = rounded(Color.parseColor("#0E1428"), 12)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        keyCard.addView(keyInput, lp(topMargin = 12))
        keyCard.addView(button("Save Key", colorAccent) {
            saveKey()
            toast("API key saved")
        }, lp(topMargin = 12))
        root.addView(keyCard, lp(topMargin = 0))

        // Permissions card
        val permCard = card()
        permCard.addView(text("Permissions", 16f, Color.WHITE, true))
        micStatus = text("", 14f, Color.WHITE, false).apply { setPadding(0, dp(10), 0, 0) }
        overlayStatus = text("", 14f, Color.WHITE, false).apply { setPadding(0, dp(6), 0, 0) }
        permCard.addView(micStatus)
        permCard.addView(overlayStatus)
        permCard.addView(button("Grant Permissions", colorAccent) { grantPermissions() }, lp(topMargin = 12))
        root.addView(permCard, lp(topMargin = 16))

        // Service card
        val serviceCard = card()
        serviceCard.addView(text("Floating Jarvis", 16f, Color.WHITE, true))
        serviceStatus = text("", 14f, colorMuted, false).apply { setPadding(0, dp(8), 0, 0) }
        serviceCard.addView(serviceStatus)
        toggleBtn = button("Start Jarvis", colorOk) { toggleService() }
        serviceCard.addView(toggleBtn, lp(topMargin = 12))
        root.addView(serviceCard, lp(topMargin = 16))

        root.addView(
            text(
                "Tap the floating mic bubble in any app, then say things like:\n" +
                    "• \"Open WhatsApp\"\n• \"Call 555 123 4567\"\n• \"What's the capital of France?\"",
                13f, colorMuted, false
            ).apply { setPadding(dp(4), dp(20), dp(4), 0) }
        )

        setContentView(ScrollView(this).apply {
            setBackgroundColor(colorBg)
            isFillViewport = true
            addView(root)
        })
    }

    private fun refreshStatus() {
        val mic = hasMic()
        val overlay = canDrawOverlay()
        micStatus.text = if (mic) "✔  Microphone granted" else "✘  Microphone needed"
        micStatus.setTextColor(if (mic) colorOk else colorDanger)
        overlayStatus.text = if (overlay) "✔  Draw over other apps granted" else "✘  Draw over other apps needed"
        overlayStatus.setTextColor(if (overlay) colorOk else colorDanger)

        val running = FloatingJarvisService.isRunning
        serviceStatus.text = if (running) "Running — the bubble is visible over your apps." else "Stopped"
        toggleBtn.text = if (running) "Stop Jarvis" else "Start Jarvis"
        toggleBtn.background = rounded(if (running) colorDanger else colorOk, 14)
    }

    // ---------------------------------------------------------------- Actions

    private fun grantPermissions() {
        val missing = mutableListOf<String>()
        if (!hasMic()) missing += Manifest.permission.RECORD_AUDIO
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            missing += Manifest.permission.CALL_PHONE
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            missing += Manifest.permission.POST_NOTIFICATIONS
        }
        when {
            missing.isNotEmpty() -> permissionLauncher.launch(missing.toTypedArray())
            !canDrawOverlay() -> requestOverlayPermission()
            else -> toast("All permissions already granted")
        }
    }

    private fun requestOverlayPermission() {
        overlayLauncher.launch(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun toggleService() {
        val intent = Intent(this, FloatingJarvisService::class.java)
        if (FloatingJarvisService.isRunning) {
            stopService(intent)
            toast("Jarvis stopped")
        } else {
            val key = keyInput.text.toString().trim()
            when {
                key.isEmpty() -> { toast("Paste your Gemini API key first"); return }
                !hasMic() || !canDrawOverlay() -> { toast("Grant the required permissions first"); return }
            }
            saveKey()
            ContextCompat.startForegroundService(this, intent)
            toast("Jarvis started")
        }
        Handler(Looper.getMainLooper()).postDelayed({ refreshStatus() }, 400)
    }

    private fun saveKey() {
        prefs().edit().putString(FloatingJarvisService.KEY_API, keyInput.text.toString().trim()).apply()
    }

    private fun hasMic() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun canDrawOverlay() = Settings.canDrawOverlays(this)

    private fun prefs() = getSharedPreferences(FloatingJarvisService.PREFS, Context.MODE_PRIVATE)

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ---------------------------------------------------------------- View helpers

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(colorCard, 18)
        setPadding(dp(18), dp(16), dp(18), dp(18))
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun button(label: String, color: Int, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 15f
        setTextColor(Color.WHITE)
        background = rounded(color, 14)
        stateListAnimator = null
        setOnClickListener { onClick() }
    }

    private fun lp(topMargin: Int) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply {
        gravity = Gravity.CENTER_HORIZONTAL
        setMargins(0, dp(topMargin), 0, 0)
    }
}
