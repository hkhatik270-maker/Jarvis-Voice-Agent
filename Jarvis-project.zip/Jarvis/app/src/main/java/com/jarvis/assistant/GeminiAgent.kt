package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.MediaStore
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Sends the transcribed voice command to Gemini (gemini-2.5-flash) with function declarations,
 * then executes whichever function(s) the model calls.
 *
 * [process] must be called from the main thread; network I/O is moved to Dispatchers.IO internally.
 */
class GeminiAgent(
    private val context: Context,
    private val speak: (String) -> Unit
) {

    private data class FunctionCall(val name: String, val args: JSONObject)

    companion object {
        private const val TAG = "GeminiAgent"
        private const val MODEL = "gemini-2.5-flash"
        private const val ENDPOINT =
            "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"

        private val SYSTEM_PROMPT = """
            You are Jarvis, a concise, polite and slightly witty voice assistant living on the user's Android phone.
            The user's message is a speech transcript, so it may contain small recognition mistakes.
            Always respond by calling exactly one of the available functions:
            - open_app: when the user wants to open/launch an app. Pass the Android package name when you know it,
              otherwise pass the app's display name. Known packages: WhatsApp com.whatsapp, YouTube com.google.android.youtube,
              Instagram com.instagram.android, Facebook com.facebook.katana, Messenger com.facebook.orca,
              Telegram org.telegram.messenger, Chrome com.android.chrome, Gmail com.google.android.gm,
              Google Maps com.google.android.apps.maps, Spotify com.spotify.music, Settings com.android.settings,
              Play Store com.android.vending, Photos com.google.android.apps.photos, TikTok com.zhiliaoapp.musically,
              X/Twitter com.twitter.android, Snapchat com.snapchat.android, Netflix com.netflix.mediaclient.
              For the camera, pass the word "camera".
            - make_call: when the user wants to call a phone number. Pass digits only (keep a leading + if present).
            - general_conversation: for everything else (questions, chit-chat, confirmations, or when you cannot do
              what was asked). Keep spoken answers short (1-3 sentences), natural, and without markdown or emojis.
            Reply in the same language the user spoke.
        """.trimIndent()
    }

    suspend fun process(userText: String, apiKey: String) {
        val calls = try {
            withContext(Dispatchers.IO) { callGemini(userText, apiKey) }
        } catch (e: Exception) {
            Log.e(TAG, "Gemini request failed", e)
            speak("Sorry, I could not reach Gemini. ${e.message?.take(120).orEmpty()}")
            return
        }

        if (calls.isEmpty()) {
            speak("Sorry, I did not understand that.")
            return
        }
        calls.forEach { execute(it) }
    }

    // ------------------------------------------------------------------ Gemini REST call

    private fun callGemini(userText: String, apiKey: String): List<FunctionCall> {
        val body = JSONObject().apply {
            put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM_PROMPT))))
            put(
                "contents",
                JSONArray().put(
                    JSONObject()
                        .put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", userText)))
                )
            )
            put("tools", JSONArray().put(JSONObject().put("functionDeclarations", declarations())))
            put(
                "toolConfig",
                JSONObject().put("functionCallingConfig", JSONObject().put("mode", "ANY"))
            )
            put(
                "generationConfig",
                JSONObject()
                    .put("temperature", 0.4)
                    .put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
            )
        }

        val conn = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15_000
            readTimeout = 45_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("x-goog-api-key", apiKey)
        }

        try {
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val response = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()

            if (code !in 200..299) {
                val msg = runCatching {
                    JSONObject(response).getJSONObject("error").getString("message")
                }.getOrDefault("HTTP $code")
                throw IOException(msg)
            }
            return parseCalls(response)
        } finally {
            conn.disconnect()
        }
    }

    private fun parseCalls(response: String): List<FunctionCall> {
        val result = mutableListOf<FunctionCall>()
        val parts = JSONObject(response)
            .optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts") ?: return result

        for (i in 0 until parts.length()) {
            val part = parts.optJSONObject(i) ?: continue
            val fc = part.optJSONObject("functionCall")
            if (fc != null) {
                result += FunctionCall(fc.optString("name"), fc.optJSONObject("args") ?: JSONObject())
            } else if (part.has("text") && part.optString("text").isNotBlank()) {
                // Model answered in plain text instead of calling a function: treat it as conversation.
                result += FunctionCall("general_conversation", JSONObject().put("text", part.getString("text")))
            }
        }
        return result
    }

    private fun declarations(): JSONArray = JSONArray()
        .put(
            declaration(
                "open_app",
                "Launches an installed Android app.",
                "app_package_name",
                "Android package name (e.g. com.whatsapp) or the app's display name (e.g. WhatsApp)."
            )
        )
        .put(
            declaration(
                "make_call",
                "Starts a phone call to the given number.",
                "phone_number",
                "The phone number to call, digits only, optionally starting with +."
            )
        )
        .put(
            declaration(
                "general_conversation",
                "Speaks a reply out loud to the user in Jarvis's voice.",
                "text",
                "The exact text Jarvis should say."
            )
        )

    private fun declaration(name: String, description: String, param: String, paramDesc: String) =
        JSONObject()
            .put("name", name)
            .put("description", description)
            .put(
                "parameters",
                JSONObject()
                    .put("type", "OBJECT")
                    .put(
                        "properties",
                        JSONObject().put(param, JSONObject().put("type", "STRING").put("description", paramDesc))
                    )
                    .put("required", JSONArray().put(param))
            )

    // ------------------------------------------------------------------ Tool execution

    private fun execute(call: FunctionCall) {
        Log.d(TAG, "Executing ${call.name} ${call.args}")
        when (call.name) {
            "open_app" -> openApp(call.args.optString("app_package_name").trim())
            "make_call" -> makeCall(call.args.optString("phone_number"))
            "general_conversation" -> speak(call.args.optString("text").ifBlank { "I'm here." })
            else -> speak("Sorry, I don't know how to do that yet.")
        }
    }

    private fun openApp(target: String) {
        if (target.isEmpty()) {
            speak("Which app should I open?")
            return
        }
        val pm = context.packageManager

        // 1) Exact package name
        var launch = pm.getLaunchIntentForPackage(target)

        // 2) Match by app label (e.g. "WhatsApp")
        if (launch == null) {
            val mainIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            @Suppress("DEPRECATION")
            val apps = pm.queryIntentActivities(mainIntent, 0)
            val match = apps.firstOrNull { it.loadLabel(pm).toString().equals(target, ignoreCase = true) }
                ?: apps.firstOrNull { it.loadLabel(pm).toString().contains(target, ignoreCase = true) }
            if (match != null) launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
        }

        // 3) Camera special case
        if (launch == null && target.contains("camera", ignoreCase = true)) {
            launch = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
        }

        if (launch == null) {
            speak("I couldn't find that app on your phone.")
            return
        }
        try {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launch)
        } catch (e: Exception) {
            Log.e(TAG, "openApp failed", e)
            speak("Sorry, I couldn't open that app.")
        }
    }

    private fun makeCall(rawNumber: String) {
        val number = rawNumber.filterIndexed { i, c -> c.isDigit() || (i == 0 && c == '+') }
        if (number.isEmpty()) {
            speak("I didn't catch the phone number.")
            return
        }
        val canCallDirectly = ContextCompat.checkSelfPermission(
            context, android.Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED

        val intent = Intent(
            if (canCallDirectly) Intent.ACTION_CALL else Intent.ACTION_DIAL,
            Uri.fromParts("tel", number, null)
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e(TAG, "makeCall failed", e)
            speak("Sorry, I couldn't start the call.")
        }
    }
}
