package com.jarvis.assistant

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.Toast
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.Locale

class FloatingJarvisService : Service() {

    companion object {
        const val PREFS = "jarvis_prefs"
        const val KEY_API = "gemini_api_key"
        const val ACTION_STOP = "com.jarvis.assistant.ACTION_STOP"

        private const val TAG = "FloatingJarvis"
        private const val CHANNEL_ID = "jarvis_service"
        private const val NOTIFICATION_ID = 1001

        @Volatile
        var isRunning = false
            private set
    }

    private enum class State { IDLE, LISTENING, THINKING, SPEAKING }

    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private lateinit var windowManager: WindowManager
    private lateinit var agent: GeminiAgent
    private var bubble: FrameLayout? = null
    private var bubbleBg: GradientDrawable? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var pulse: ObjectAnimator? = null

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var state = State.IDLE

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        startAsForeground()

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Overlay permission missing", Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }

        if (bubble == null) {
            isRunning = true
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            agent = GeminiAgent(this) { speak(it) }
            initTts()
            createBubble()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        isRunning = false
        pulse?.cancel()
        handler.removeCallbacksAndMessages(null)
        bubble?.let { runCatching { windowManager.removeView(it) } }
        bubble = null
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        scope.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ Foreground notification

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Jarvis", NotificationManager.IMPORTANCE_LOW)
        )

        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, FloatingJarvisService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Jarvis is active")
            .setContentText("Tap the floating mic to talk")
            .setContentIntent(openApp)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Stop", stop).build())
            .build()

        val type = if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, type)
    }

    // ------------------------------------------------------------------ Floating bubble

    @SuppressLint("ClickableViewAccessibility")
    private fun createBubble() {
        val size = dp(64)

        val bg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(colorFor(State.IDLE))
        }
        bubbleBg = bg

        val icon = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_btn_speak_now)
            setColorFilter(Color.WHITE)
            setPadding(dp(17), dp(17), dp(17), dp(17))
        }

        val frame = FrameLayout(this).apply {
            background = bg
            elevation = dp(8).toFloat()
            addView(icon, FrameLayout.LayoutParams(size, size))
        }

        val params = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(220)
        }
        bubbleParams = params

        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var dragging = false

        frame.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    dragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - touchX
                    val dy = event.rawY - touchY
                    if (!dragging && (kotlin.math.abs(dx) > touchSlop || kotlin.math.abs(dy) > touchSlop)) {
                        dragging = true
                    }
                    if (dragging) {
                        params.x = startX + dx.toInt()
                        params.y = startY + dy.toInt()
                        runCatching { windowManager.updateViewLayout(frame, params) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragging) onBubbleTapped()
                    true
                }
                else -> false
            }
        }

        windowManager.addView(frame, params)
        bubble = frame
    }

    private fun setState(newState: State) {
        state = newState
        bubbleBg?.setColor(colorFor(newState))
        bubble?.invalidate()

        pulse?.cancel()
        bubble?.let { it.scaleX = 1f; it.scaleY = 1f }
        if (newState == State.LISTENING) {
            bubble?.let {
                pulse = ObjectAnimator.ofPropertyValuesHolder(
                    it,
                    PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.2f),
                    PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.2f)
                ).apply {
                    duration = 600
                    repeatCount = ObjectAnimator.INFINITE
                    repeatMode = ObjectAnimator.REVERSE
                    start()
                }
            }
        }
    }

    private fun colorFor(s: State) = when (s) {
        State.IDLE -> Color.parseColor("#2979FF")
        State.LISTENING -> Color.parseColor("#E53935")
        State.THINKING -> Color.parseColor("#FB8C00")
        State.SPEAKING -> Color.parseColor("#43A047")
    }

    // ------------------------------------------------------------------ Tap -> listen

    private fun onBubbleTapped() {
        when (state) {
            State.LISTENING -> { recognizer?.stopListening(); return }
            State.THINKING -> return
            else -> Unit
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("Microphone permission missing — open Jarvis and grant it")
            return
        }
        if (apiKey().isBlank()) {
            toast("Gemini API key missing — open Jarvis and paste it")
            return
        }

        tts?.stop()
        recognizer?.cancel()
        vibrate()
        playPromptSound()
        setState(State.LISTENING)
        // Short delay so the prompt beep isn't picked up by the recognizer.
        handler.postDelayed({ if (state == State.LISTENING) startListening() }, 300)
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("Speech recognition is not available on this device.")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(listener)
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        recognizer?.startListening(intent)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: android.os.Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: android.os.Bundle?) {}
        override fun onEvent(eventType: Int, params: android.os.Bundle?) {}

        override fun onError(error: Int) {
            Log.w(TAG, "Recognition error $error")
            setState(State.IDLE)
            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> toast("I didn't catch that")
                SpeechRecognizer.ERROR_NETWORK,
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> toast("Speech recognition network error")
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> toast("Microphone permission missing")
                SpeechRecognizer.ERROR_CLIENT -> Unit // happens on cancel()
                else -> toast("Speech error ($error)")
            }
        }

        override fun onResults(results: android.os.Bundle?) {
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()?.trim().orEmpty()
            if (text.isEmpty()) {
                setState(State.IDLE)
                toast("I didn't catch that")
                return
            }
            handleCommand(text)
        }
    }

    private fun handleCommand(text: String) {
        Log.d(TAG, "Heard: $text")
        setState(State.THINKING)
        scope.launch {
            try {
                agent.process(text, apiKey())
            } catch (e: Exception) {
                Log.e(TAG, "Agent failure", e)
                speak("Sorry, something went wrong.")
            } finally {
                if (state == State.THINKING) setState(State.IDLE)
            }
        }
    }

    // ------------------------------------------------------------------ Text to speech

    private fun initTts() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val engine = tts ?: return@TextToSpeech
                val r = engine.setLanguage(Locale.getDefault())
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    engine.setLanguage(Locale.US)
                }
                engine.setPitch(0.85f)
                engine.setSpeechRate(1.0f)
                engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        handler.post { if (state == State.SPEAKING) setState(State.IDLE) }
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        handler.post { if (state == State.SPEAKING) setState(State.IDLE) }
                    }
                })
                ttsReady = true
            } else {
                Log.e(TAG, "TTS init failed: $status")
            }
        }
    }

    private fun speak(text: String) {
        if (!ttsReady) {
            toast(text)
            setState(State.IDLE)
            return
        }
        setState(State.SPEAKING)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_utterance")
    }

    // ------------------------------------------------------------------ Helpers

    private fun apiKey(): String =
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_API, "")?.trim().orEmpty()

    private fun vibrate() {
        val vibrator: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
            (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(VIBRATOR_SERVICE) as Vibrator
        }
        vibrator.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    private fun playPromptSound() {
        runCatching {
            val tone = ToneGenerator(AudioManager.STREAM_MUSIC, 80)
            tone.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
            handler.postDelayed({ tone.release() }, 400)
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
